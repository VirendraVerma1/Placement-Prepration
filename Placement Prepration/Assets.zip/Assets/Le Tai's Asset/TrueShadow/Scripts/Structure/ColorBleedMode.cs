namespace LeTai.TrueShadow
{
public enum ColorBleedMode
{
    ImageColor,
    ShadowColor,
    Black,
    White,
    Plugin
}
}
