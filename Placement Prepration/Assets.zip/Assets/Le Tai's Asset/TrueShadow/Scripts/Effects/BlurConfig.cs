using UnityEngine;

namespace LeTai.Effects
{
    public class BlurConfig : ScriptableObject
    {

    }
}
