using UnityEngine;

namespace LeTai.TrueShadow
{
public class KnobAttribute : PropertyAttribute { }

public class ToggleButtonsAttribute : PropertyAttribute { }

public class InsetToggleAttribute : ToggleButtonsAttribute { }
}
